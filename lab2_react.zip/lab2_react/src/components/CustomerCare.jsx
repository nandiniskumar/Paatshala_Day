import React from 'react';

function CustomerCare(){
    return(
        <div>
            <h4>Message from Customer Care</h4>
        </div>
    )
}
export default CustomerCare;