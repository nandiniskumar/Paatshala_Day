import React from 'react';

function Services(){
    return(
        <div>
            <h4>Message from Services</h4>
        </div>
    )
}
export default Services;