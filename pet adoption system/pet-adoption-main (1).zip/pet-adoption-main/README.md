Welcome to Adopt-o-Pet! A web application for a Pet Adoption Agency!

This was a 1 day exercise focusing on Flask and SQLAlchemy.. definitely NOT design ;)

To view the app please complete the following steps:

- download the code by using git clone
- cd into the folder and type python3 -m venv venv
- activate the venv with source venv/bin/activate
- install all the necessary requirements with pip3 install -r requirements.txt
- in your terminal type createdb adopt
- LASTLY type flask run to start your local server on port 5000

visit localhost:5000/ where you can add pets and their info to a page for adopters to see!.