const Header = () => {
    return (
            <header className="header">
            <div className="wrapper">
                <h1>HOUSE RENTAL SYSTEM</h1>
            </div>
            
        </header>
    )
}

export default Header;